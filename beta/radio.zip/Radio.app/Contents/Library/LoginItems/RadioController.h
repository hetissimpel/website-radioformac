//
//  RadioController
//  Viscis
//
//  Created by dglancy on 04/11/2012.
//  Copyright (c) 2012 Viscis. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Channel.h"
#import "Recording.h"

#import "Radio.h"
#import "HTTPRadio.h"
#import "MMSRadio.h"

@interface RadioController : NSObject<RadioDelegate>

@property (strong) Radio *radio;
@property (strong, nonatomic) Channel *selectedChannel;

@property (assign, nonatomic) BOOL recordActive;
@property (assign, nonatomic) BOOL playActive;
@property (assign, nonatomic) BOOL favouriteActive;
@property (assign, nonatomic) BOOL recordingAllowed;

- (void)playChannel:(Channel *)channel;
- (void)startRecording;
- (void)stopRecording;
- (void)stop;

@end